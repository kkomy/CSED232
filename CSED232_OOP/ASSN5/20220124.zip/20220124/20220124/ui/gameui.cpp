#include "ui/gameui.h"
#include <QMessageBox>


GameUI::GameUI()
{

    QFile file("progress.txt");
    file.open(QFile::WriteOnly | QFile::Text);
    QTextStream out(&file);

    resize(1300,1000);

    gameboard = new QGridLayout(this);

    /*레이아웃 설정*//////////////////////////////////////////////////
    exit = new QPushButton("Exit", this);
    restore = new QPushButton("Restore",this);
    score = new QLabel("Score: 0", this);
    connect(exit, SIGNAL(clicked()), this, SLOT(exit_push()));
    connect(restore, SIGNAL(clicked()), this, SLOT(restore_push()));

    restore->setFixedSize(300,200);
    exit->setFixedSize(300,200);

    score_line = new QHBoxLayout;
    score_line->addWidget(score,0, Qt::AlignTop | Qt::AlignHCenter);
    menu = new QVBoxLayout;
    menu->addWidget(restore,0,Qt::AlignBottom);
    menu->addWidget(exit,0,Qt::AlignBottom);
    total = new QVBoxLayout(this);
    total->addLayout(score_line);
    total->addStretch();
    total->addLayout(menu);
    gameboard->addLayout(total,0,4,0,4,Qt::AlignLeft | Qt::AlignTop);


    restore->setFocusPolicy(Qt::NoFocus);
    exit->setFocusPolicy(Qt::NoFocus);

    QFont font;
    font.setPointSize(20);
    QFont font1;
    font1.setPointSize(40);
    score->setFont(font1);
    restore->setFont(font);
    exit->setFont(font);
    //////////////////////////////////////////////////////////////////


    brd.start_random(); // board판 랜덤만들기


    /*초기 블럭 랜덤 세팅*/////////////////////////////////////
    out << "INITIAL ";
    for(int row = 0; row < 4; row++){
        for(int col = 0;col < 4;col++){
            if(brd.gaming[row][col].get_value() != 0){
               blo[row][col] = new BlockUI(2);
               blo[row][col]->setcolor(2);
               out << row + 1 << " " << col + 1 << " ";
            }
            else {
                blo[row][col] = new BlockUI(0);
                blo[row][col]->setcolor(0);
            }

            gameboard->addWidget(blo[row][col], row, col);
            gameboard->setSpacing(10);

        }
    }
    out << "\n";
    file.flush();
    file.close();
    ///////////////////////////////////////////////////

    setFocusPolicy(Qt::StrongFocus);
}


/*exit버튼*/
void GameUI::exit_push(){
    QMessageBox::StandardButton quest;
    quest = QMessageBox::question(this, "Exit", "Are you sure to quit?", QMessageBox::Yes | QMessageBox::No);
    if(quest == QMessageBox::Yes){
        close();
    }
}

/*restore버튼*/
void GameUI::restore_push(){
    QFile file("progress.txt");
    file.open(QFile::Append | QFile::Text);
    QTextStream out(&file);

    QMessageBox::StandardButton quest;

    if(buffer_check > 0){ // 만약 buffer가 존재하면
        if(restore_num > 0){ // restore횟수가 남아있다면
            quest = QMessageBox::question(this, "Restore", "Restore the game board to its previous state? \n \nRemaining chances: " + QString::number(restore_num), QMessageBox::Yes | QMessageBox::No);
            if(quest == QMessageBox::Yes){
                restore_num--; // 리스토어 횟수 차감
                out << "RESTORE" << " " << restore_num << "\n";
                for(int i=0;i<4;i++){
                    for(int j=0;j<4;j++){
                        brd.gaming[i][j].change_value(buffer[i][j]); // 이전 단계의 블럭으로 모두 바꾸기
                    }
                }
                for(int i=0;i<4;i++){
                    for(int j=0;j<4;j++){
                        delete blo[i][j];
                    }
                }
                for(int i=0;i<4;i++){
                    for(int j=0;j<4;j++){ // 바뀐 결과를 화면에 display하기
                        blo[i][j] = new BlockUI(brd.gaming[i][j].get_value());
                        blo[i][j]->setcolor(brd.gaming[i][j].get_value());
                        gameboard->addWidget(blo[i][j],i,j);
                    }
                }
                buffer_check--; // 버퍼가 없으므로 0으로 만들기
            }
        }
        else{ // restore 횟수가 남아있지 않다면
            quest = QMessageBox::critical(this, "Restore", "No more chance to restore the board to its previous state.", QMessageBox::Ok);

        }
    }
    else{ // buffer가 없다면
        if(restore_num == 0){ // restore 횟수가 남아있지 않은 것이 우선순위이므로 먼저 출력
           quest = QMessageBox::critical(this, "Restore", "No more chance to restore the board to its previous state.", QMessageBox::Ok);

        }
        else{ // restore 횟수는 있지만 buffer가 없다면
        quest = QMessageBox::critical(this, "Restore", "There is no previously saved board in the buffer.", QMessageBox::Ok);
        }

    }

}

void GameUI::keyPressEvent(QKeyEvent *key){
    if(manager.lose_check() == 1){
        losesignal();
    }
    buffer_check = 0; // buffer 존재여부 초기화



    for (int i = 0; i < 4; ++i) {
        for(int j=0;j<4;j++){
            buffer[i][j] = brd.gaming[i][j].get_value(); // 바꾸기 전 buffer에 이전 단계 저장
        }
    }
    buffer_check++; // buffer가 생겼으므로 ++;

    if(key->key() == Qt::Key_Up){
        brd.moveboard(board::up);
    }
    else if(key->key() == Qt::Key_Down){
        brd.moveboard(board::down);
    }
    else if(key->key() == Qt::Key_Left){
        brd.moveboard(board::left);
    }
    else if(key->key() == Qt::Key_Right){
        brd.moveboard(board::right);
    }

    for(int i=0;i<4;i++){
        for(int j=0;j<4;j++){
            delete blo[i][j];
        }
    }

    for(int i=0;i<4;i++){
        for(int j=0;j<4;j++){ //바뀐 결과 display
            blo[i][j] = new BlockUI(brd.gaming[i][j].get_value());
            blo[i][j]->setcolor(brd.gaming[i][j].get_value());
            gameboard->addWidget(blo[i][j],i,j);
        }
    }
    for(int i=0;i<4;i++){
        for(int j=0;j<4;j++){
            manager.game_system[i][j].change_value(brd.gaming[i][j].get_value());
        }
    }

    score->setText("Score: " +QString::number(brd.score)); // 점수갱신

    if(manager.win_check() == 1){ // 이겼다면
        QTimer::singleShot(1000,this,SLOT(winsignal())); // 1초뒤 winsignal 실행
    }



}
void GameUI::winsignal(){
    QMessageBox::StandardButton quest;
    quest = QMessageBox::information(this, "Win", "Congratulation! \n \nScore: " + QString::number(brd.score), QMessageBox::Ok);
    if(quest == QMessageBox::Ok){
        close();
    }
}



void GameUI::losesignal(){
    QMessageBox::StandardButton quest;
    quest = QMessageBox::information(this, "Lose", "You lose... \n \nScore: " + QString::number(brd.score), QMessageBox::Ok);
    if(quest == QMessageBox::Ok){
        close();
    }
}

GameUI::~GameUI(){
    for(int i=0;i<4;i++){
        for(int j=0;j<4;j++){
            delete blo[i][j];
        }
    }
    /*할당해제*/
    delete restore;

    delete exit;
    delete menu;


    delete score;
    delete score_line;
    delete total;

    delete gameboard;

}

