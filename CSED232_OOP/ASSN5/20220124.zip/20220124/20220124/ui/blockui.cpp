#include "ui/blockui.h"
#include <string>

BlockUI::BlockUI()
{
    setFixedSize(250, 250);
}
BlockUI::BlockUI(int v) : block(v){
    setFixedSize(250, 250); // 크기설정
    setAlignment(Qt::AlignCenter); // 중앙에 맞추기
    if(v != 0){ // 0이 아니라면
    setText(QString::number(v)); // 글씨표시
    }
}

void BlockUI::setcolor(int value){ // 색깔 구현
    switch(value){
    case 2:
        setStyleSheet("QLabel { background:  rgb(187, 173, 160); color: black; border-style: solid; font: 70pt; font: bold; }");
        break;
    case 4:
        setStyleSheet("QLabel { background:  rgb(237, 224, 200); color: black; border-style: solid; font: 70pt; font: bold; }");
        break;
    case 8:
        setStyleSheet("QLabel { background:  rgb(242, 177, 121); color: black; border-style: solid; font: 70pt; font: bold; }");
        break;
    case 16:
        setStyleSheet("QLabel { background:  rgb(245, 149, 99); color: black; border-style: solid; font: 70pt; font: bold; }");
        break;
    case 32:
        setStyleSheet("QLabel { background:  rgb(246, 126, 95); color: black; border-style: solid; font: 70pt; font: bold; }");
        break;
    case 64:
        setStyleSheet("QLabel { background:  rgb(246, 94, 59); color: black; border-style: solid; font: 70pt; font: bold; }");
        break;
    case 128:
        setStyleSheet("QLabel { background:  rgb(237, 207, 114); color: black; border-style: solid; font: 70pt; font: bold; }");
        break;
    case 256:
        setStyleSheet("QLabel { background:   rgb(237, 204, 97); color: black; border-style: solid; font: 70pt; font: bold; }");
        break;
    case 512:
        setStyleSheet("QLabel { background:  rgb(237, 200, 80); color: black; border-style: solid; font: 70pt; font: bold; }");
        break;
    case 1024:
        setStyleSheet("QLabel { background:   rgb(237, 197, 63); color: black; border-style: solid; font: 70pt; font: bold; }");
        break;
    case 2048:
        setStyleSheet("QLabel { background:  rgb(237, 194, 46); color: black; border-style: solid; font: 70pt; font: bold; }");
        break;
    default:
        setStyleSheet("QLabel { background: rgb(255, 255, 255); color: black; border-style: solid; font: 70pt; font: bold; }");
        break;
    }




}
