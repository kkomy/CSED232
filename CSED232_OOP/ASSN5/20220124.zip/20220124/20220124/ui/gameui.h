#ifndef GAMEUI_H
#define GAMEUI_H
#include <QWidget>
#include <QLabel>
#include <QGridLayout>
#include <QPushButton>
#include "ui/blockui.h"
#include "game/board.h"
#include "game/game.h"
#include <QKeyEvent>
#include <QTimer>
#include <QFile>
#include <QTextStream>


class GameUI : public QWidget
{
    Q_OBJECT
private:
    /*레이아웃 관련 변수*/
    QLabel *score;
    QGridLayout *gameboard;
    QPushButton *restore;
    QPushButton *exit;
    QVBoxLayout *total;
    QVBoxLayout* menu;
    QHBoxLayout* score_line;

    BlockUI *blo[4][4]; // display용 배열

    int restore_num = 3; // restore횟수
    int buffer_check = 0; // buffer 존재확인용



public:
    board brd; // 실제 2048 배열이 존재하는 곳
    game manager; // 게임 승리,패배 관련 컨트롤타워
    int buffer[4][4] = {}; // restore을 위한 이전단계 저장용 버퍼
    GameUI();
    ~GameUI();


public slots:
    void winsignal(); // 이길때
    void losesignal(); // 질 때
    void exit_push(); // 나갈 때
    void restore_push(); // restore할때
    void keyPressEvent(QKeyEvent *key); // 키보드 입력 함수


};

#endif // GAMEUI_H
