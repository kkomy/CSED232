#ifndef BLOCKUI_H
#define BLOCKUI_H
#include <QLabel>
#include "game/block.h"



class BlockUI : public QLabel, virtual public block
{
    Q_OBJECT
private:

public:
    BlockUI();
    BlockUI(int v);
    void setcolor(int value);


};

#endif // BLOCKUI_H
