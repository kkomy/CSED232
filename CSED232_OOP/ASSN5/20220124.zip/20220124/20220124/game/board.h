#ifndef BOARD_H
#define BOARD_H
#include<cstdlib>
#include<ctime>
#include "block.h"
#include <QFile>
#include <QTextStream>


class board : public block
{
public:
    block gaming[4][4] = {}; // 실제 2048 게임판의 블럭들
    int previous[16] = {}; // 이전 상황의 블럭 배치도
    int merge[4][4] = {}; // 합쳐진 블럭들을 기록하기 위한 배열



    enum direction{
        up,
        down,
        left,
        right
    };


    board();
    ~board();
    board(int k);
    void start_random();
    void make_random();
    void moveboard(direction key);
    void move_up();
    void move_down();
    void move_left();
    void move_right();
    int score = 0;

};

#endif // BOARD_H
