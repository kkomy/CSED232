#ifndef GAME_H
#define GAME_H
#include <QMessageBox>
#include "board.h"

class game
{
public:
    game();
    ~game();
    board game_system[4][4] = {};
    int win_check();
    int lose_check();
};

#endif // GAME_H
