#include "game/game.h"
#include <QMessageBox>

game::game()
{

}
game::~game(){
}

int game::win_check(){
    for(int i=0;i<4;i++){
        for(int j=0;j<4;j++){
            if(game_system[i][j].get_value() == 2048){ // 모든 블럭을 조사한 후, 2048의 값을 가지는 블럭이 존재하면 승리 판결
                return 1;
            }
        }
    }
    return 0;
}

int game::lose_check(){

    for(int i=0;i<4;i++){
        for(int j=0;j<4;j++){
            if(game_system[i][j].get_value() == 0){ //빈칸이 있다면
                return 0; // lose가 아님
            }
        }
    }
    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            if(game_system[i][j].get_value() == game_system[i+1][j].get_value()){ // y축으로 인접한 블럭에 같은 블럭이 있다면
                return 0; // 합쳐질 수 있으므로 lose가 아님
            }
            else if(game_system[i][j].get_value() == game_system[i][j+1].get_value()){ // x축으로 인접한 블럭에 같은 블럭이 있다면
                return 0; // lose가 아님
            }
        }
    }
    for(int i=0;i<3;i++){
        if(game_system[i][3].get_value() == game_system[i+1][3].get_value()){ // 배열 구조로 인해 x,y축이 3일때는 별도로 처리
            return 0;
        }
    }
    for(int j=0;j<3;j++){
        if(game_system[3][j].get_value() == game_system[3][j+1].get_value()){
            return 0;
        }
    }
    return 1; // 위의 조건을 하나라도 충족하지 못하면 lose
}
