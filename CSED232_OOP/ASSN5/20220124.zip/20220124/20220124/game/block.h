#ifndef BLOCK_H
#define BLOCK_H


class block
{

private:
    int value = 0;

public:
    block();
    block(int v);
    int get_value();
    void change_value(int k);
    void combine_value();
};

#endif // BLOCK_H
