#include "game/board.h"
#include<cstdlib>
#include<ctime>
board::board(){
    for (int row = 0; row < 4; ++row) {
        for (int col = 0; col < 4; ++col) {
            gaming[row][col].change_value(0);
        }
    }

}
board::board(int k)
{
    for (int row = 0; row < k; ++row) {
        for (int col = 0; col < 4; ++col) {
            gaming[row][col].change_value(0);
        }
    }


}


void board::start_random(){ // 게임이 시작될 때 2블럭을 랜덤하게 2개 만드는 함수
    std::srand(std::time(0));
    int cnt = 0;
    int row;
    int col;
    while (cnt < 2) {
        row = std::rand() % 4;
        col = std::rand() % 4;
        if (gaming[row][col].get_value() == 0) {
            gaming[row][col].change_value(2);
            cnt++;
        }
    }

}

void board::make_random(){ // 2 또는 4 블럭을 확률에 따라 빈 곳에 생성하는 함수
    QFile file("progress.txt");
    file.open(QFile::Append);
    QTextStream out(&file);

    std::srand(std::time(0));
    int cnt = 0;
    int row;
    int col;
    while (cnt != 1){
        row = std::rand() % 4;
        col = std::rand() % 4;
        if(gaming[row][col].get_value() == 0){
            int randomian = std::rand() % 10; // 20%확률로 4가 생성, 80%확률로 2가 생성
            if(randomian >= 0 && randomian <=1){
                gaming[row][col].change_value(4);

                out << "GENERATE " << row + 1 << " " << col + 1 << " " << "4" << "\n"; // 4가 만들어졌을 때 파일 입력

            }
            else {
                gaming[row][col].change_value(2);

                out << "GENERATE " << row + 1 << " " << col + 1 << " " << "2" << "\n"; // 2가 만들어졌을 때 파일 입력

            }
            cnt++;
        }
    }
    out << "SCORE" << " " << score << "\n";
    file.flush();
    file.close();
}

void board::moveboard(direction key){

    for(int i=0;i<4;i++){
     for(int j=0;j<4;j++){
       previous[i*4+j] = gaming[i][j].get_value(); // 이전상황 기록

     }

    }
    switch(key){
    case up:
        move_up();
        break;
    case down:
        move_down();
        break;
    case left:
        move_left();
        break;
    case right:
        move_right();
        break;
    }
    QFile file("progress.txt");
    file.open(QFile::Append | QFile::Text);
    QTextStream out(&file);
    for(int i=0;i<4;i++){
        for(int j=0;j<4;j++){
       if(merge[i][j] != 0){ // 만약 0이 아니라면, 즉 합쳐진 블록이 존재한다면
         out << "MERGE" << " " << i + 1 << " " << j + 1 << " " << merge[i][j] << "\n"; // 해당 블록을 파일에 입력
       }

        }
    }
    for(int i=0;i<4;i++){
        for(int j=0;j<4;j++){
       merge[i][j] = 0; // 다음 단계를 위한 merge 초기화
        }
    }
    file.flush();
    file.close();


   int flag = 0;
   for(int i=0;i<4;i++){
      for(int j=0;j<4;j++){
          if(previous[i*4+j] == gaming[i][j].get_value()){ // 만약 이전단계와 현 단계의 블럭 배치가 같다면
            flag++;
      }
    }
   }
   if(flag != 16){ // flag가 16이라면, 즉 게임판에 존재하는 모든 블록이 이전단계와 같다면 움직이지 않은 것이므로 새로운 블럭을 생성하지 않음
      make_random();

    }

}

board::~board(){
       for(int i=0;i<4;i++){
        for(int j=0;j<4;j++){
            gaming[i][j].change_value(0);
        }
       }

}


void board::move_up(){
       QFile file("progress.txt");
       file.open(QFile::Append | QFile::Text);
       QTextStream out(&file);

       out << "UP" << "\n";


       for(int j=0;j<4;++j){
        bool check[4] = {}; // 합친 이력을 기록하는 배열. 처음에는 다 false로

        for(int i=0;i<4;++i){
            int next_i = i - 1; // 다음 번째의 블록 좌표
            int next_j = j;

            if(next_i >= 0 && next_j >= 0 && gaming[i][j].get_value() != 0){

                while(next_i >= 0 && next_i < 4 && next_j >= 0 && next_j < 4){ // 이동할 수 있을 때까지 쭉 이동


                    if(gaming[next_i][next_j].get_value() == 0){ // 이동했을 때 해당 위치에 블럭이 없을 때
                        gaming[next_i][next_j].change_value(gaming[i][j].get_value());
                        gaming[i][j].change_value(0);
                        i = next_i;
                        j = next_j;
                        next_i -= 1;

                    }
                    else if(gaming[next_i][next_j].get_value() == gaming[i][j].get_value()){
                        if(check[next_i] == false){ // 만약 합쳐진 적이 없다면
                            check[next_i] = true; // 합칠 것이므로 체크
                            gaming[next_i][next_j].combine_value(); // 블럭 합치기
                            score += gaming[next_i][next_j].get_value(); // 점수기록
                            gaming[i][j].change_value(0);
                            merge[next_i][next_j] = gaming[next_i][next_j].get_value(); // merge배열에 해당 위치의 블럭이 합쳐진 블럭임을 기록
                            //out << "MERGE" << " " << next_i + 1 << " " << next_j + 1 << " " << gaming[next_i][next_j].get_value() << "\n";

                        }

                        break;
                    }
                    else break;
                }
            }
        }

       }
       file.flush();
       file.close();

}

void board::move_down(){
       QFile file("progress.txt");
       file.open(QFile::Append | QFile::Text);
       QTextStream out(&file);

       out << "DOWN" << "\n";


       for(int j=0;j<4;++j){
        bool check[4] = {};

        for(int i=3;i>=0;--i){
            int next_i = i + 1;
            int next_j = j;


            if(next_i >= 0 && next_j >= 0 && gaming[i][j].get_value() != 0){

                while(next_i >= 0 && next_i < 4 && next_j >= 0 && next_j < 4){ // 이동할 수 있을 때까지 쭉 이동

                    if(gaming[next_i][next_j].get_value() == 0){ // 이동했을 때 해당 위치에 블럭이 없을 때
                        gaming[next_i][next_j].change_value(gaming[i][j].get_value());
                        gaming[i][j].change_value(0);
                        i = next_i;
                        j = next_j;
                        next_i += 1;

                    }
                    else if(gaming[next_i][next_j].get_value() == gaming[i][j].get_value()){
                        if(check[next_i] == false){
                            check[next_i] = true;
                            gaming[next_i][next_j].combine_value();
                            gaming[i][j].change_value(0);
                            score += gaming[next_i][next_j].get_value();
                            merge[next_i][next_j] = gaming[next_i][next_j].get_value();
                            //out << "MERGE" << " " << next_i + 1 << " " << next_j + 1 << " " << gaming[next_i][next_j].get_value() << "\n";
                        }
                        break;
                    }
                    else break;
                }
            }
        }
       }
       file.flush();
       file.close();
\

}
void board::move_left(){
       QFile file("progress.txt");
       file.open(QFile::Append | QFile::Text);
       QTextStream out(&file);

       out << "LEFT" << "\n";


       for(int i=0;i<4;++i){
        bool check[4] = {};
        for(int j=0;j<4;++j){
            int next_i = i;
            int next_j = j - 1;

            if(next_i >= 0 && next_j >= 0 && gaming[i][j].get_value() != 0){

                while(next_i >= 0 && next_i < 4 && next_j >= 0 && next_j < 4){ // 이동할 수 있을 때까지 쭉 이동

                    if(gaming[next_i][next_j].get_value() == 0){ // 이동했을 때 해당 위치에 블럭이 없을 때
                        gaming[next_i][next_j].change_value(gaming[i][j].get_value());
                        gaming[i][j].change_value(0);
                        i = next_i;
                        j = next_j;
                        next_j -= 1;

                    }
                    else if(gaming[next_i][next_j].get_value() == gaming[i][j].get_value() ){
                        if(check[next_j] == false){
                            check[next_j] = true;
                            gaming[next_i][next_j].combine_value();
                            gaming[i][j].change_value(0);
                            score += gaming[next_i][next_j].get_value();
                            merge[next_i][next_j] = gaming[next_i][next_j].get_value();
                            //out << "MERGE" << " " << next_i + 1 << " " << next_j + 1 << " " << gaming[next_i][next_j].get_value() << "\n";
                        }
                        break;
                    }
                    else break;
                }
            }
        }
       }
       file.flush();
       file.close();
\

}
void board::move_right(){
       QFile file("progress.txt");
       file.open(QFile::Append | QFile::Text);
       QTextStream out(&file);
       out << "RIGHT" << "\n";

       for(int i=0;i<4;++i){
        bool check[4] = {};
        for(int j=3;j>=0;--j){
            int next_i = i;
            int next_j = j + 1;

            if(next_i >= 0 && next_j >= 0 && gaming[i][j].get_value() != 0){

                while(next_i >= 0 && next_i < 4 && next_j >= 0 && next_j < 4){ // 이동할 수 있을 때까지 쭉 이동

                    if(gaming[next_i][next_j].get_value() == 0){ // 이동했을 때 해당 위치에 블럭이 없을 때
                        gaming[next_i][next_j].change_value(gaming[i][j].get_value());
                        gaming[i][j].change_value(0);
                        i = next_i;
                        j = next_j;
                        next_j += 1;

                    }
                    else if(gaming[next_i][next_j].get_value() == gaming[i][j].get_value()){
                        if(check[next_j] == false){
                            check[next_j] = true;
                            gaming[next_i][next_j].combine_value();
                            gaming[i][j].change_value(0);
                            score += gaming[next_i][next_j].get_value();
                            merge[next_i][next_j] = gaming[next_i][next_j].get_value();
                            //out << "MERGE" << " " << next_i + 1 << " " << next_j + 1 << " " << gaming[next_i][next_j].get_value() << "\n";
                        }
                        break;

                    }
                    else break;
                }
            }
        }
       }
       file.flush();
       file.close();
\

}
