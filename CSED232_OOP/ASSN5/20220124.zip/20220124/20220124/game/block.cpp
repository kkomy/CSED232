#include "game/block.h"

block::block()
{
    value = 0;

}
block::block(int v){
    value = v;
}

int block::get_value(){
    return value;
}

void block::change_value(int k){ // block 값을 바꾼다.
    value = k;
}
void block::combine_value(){ // 같은 블럭이 충돌했을 때 결합시킨다. 즉, 값을 2배로 만드는 함수
  value *=2;
}
